package com.rakuten.letsmeet.letsmeetbackend.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rakuten.letsmeet.letsmeetbackend.dao.MeetingRoomDao;
import com.rakuten.letsmeet.letsmeetbackend.model.MeetingRooms;
import com.rakuten.letsmeet.letsmeetbackend.service.MeetingRoomService;

@RestController
//@EnableGlobalMethodSecurity
@RequestMapping("/api")
@CrossOrigin("http://localhost:4200")
public class MeetingRoomRestController {

	private MeetingRoomService meetingRoomService;
	
	//inject MeetingRoomDao
	@Autowired
	public MeetingRoomRestController(MeetingRoomService theMeetingRoomService) {
		meetingRoomService = theMeetingRoomService;
	}
	
	@GetMapping("/meetingroom")
	public List<MeetingRooms> findAll() {
		return meetingRoomService.findAll();
	}
	
	@GetMapping("/meetingroom/{roomId}")
	public MeetingRooms getMeetingroom(@PathVariable int roomId) {
		MeetingRooms theMeetingRoom = meetingRoomService.findById(roomId);
		if(theMeetingRoom == null) {
			throw new RuntimeException("Meeting room id not found - "+roomId);
		}
		return theMeetingRoom;
	}
	
	@PostMapping("/add")
	public MeetingRooms add(@RequestBody MeetingRooms theMeetingRoom) {
		//also just in case they pass an id in JSON..id. set id to 0
		// this is to force a save of new item... instead of update
//		theMeetingRoom.setRoomId(0);
		meetingRoomService.add(theMeetingRoom);
		return theMeetingRoom;
	}
	
	//add mapping for PUT /meetingroom - update existing employee
	@PutMapping("/updatemeetingroom")
	public MeetingRooms update(@RequestBody MeetingRooms theMeetingRoom) {
		meetingRoomService.add(theMeetingRoom);
		return theMeetingRoom;
	}
	
	//add mapping for DELETE /meetingroom/{roomId} -delete meeting room
	@DeleteMapping("/meetingroom/{roomId}")
	public String delete(@PathVariable int roomId) {
		MeetingRooms tempRoom = meetingRoomService.findById(roomId);
		
		//throw exception if null
		if(tempRoom == null) {
			throw new RuntimeException("Meeting room id is not found - " + roomId);
		}
		meetingRoomService.deleteById(roomId);
		return "Deleted Meeting Room id - " + roomId;
		
	}
}
