package com.rakuten.letsmeet.letsmeetbackend.model;

import java.sql.Date;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;

import lombok.Data;
import lombok.NoArgsConstructor;

//@NoArgsConstructor
@Data
@Entity
@Table(name="meeting_slots")
public class MeetingSlots {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="start_time")
	private Time startTime;
	
	@Column(name="end_time")
	private Time endTime;
	
	@Column(name="date")
	private String date;
	
//	@ManyToOne(fetch=FetchType.LAZY)
//	@JoinColumn(name="Room_Id")
////	@Column(name="Meeting_Room")
//	private MeetingRooms meetingRoom;
	
//	@ManyToOne(fetch=FetchType.LAZY)
//	@JoinColumn(name="User_Id")
////	@Column(name="Booked_By")
//	private String bookedBy;
	
	@ManyToOne(fetch = FetchType.LAZY )
	@JoinColumn(name = "room_id",referencedColumnName = "room_id", nullable = false)
	private MeetingRooms meetingRoom;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id",referencedColumnName = "user_id", nullable = false )
	private Users bookedBy;
	
	public MeetingSlots() {
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Time getStartTime() {
		return startTime;
	}

	public void setStartTime(Time startTime) {
		this.startTime = startTime;
	}

	public Time getEndTime() {
		return endTime;
	}

	public void setEndTime(Time endTime) {
		this.endTime = endTime;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public MeetingRooms getMeetingRoom() {
		return meetingRoom;
	}

	public void setMeetingRoom(MeetingRooms meetingRoom) {
		this.meetingRoom = meetingRoom;
	}

	public Users getBookedBy() {
		return bookedBy;
	}

	public void setBookedBy(Users bookedBy) {
		this.bookedBy = bookedBy;
	}

	
	public MeetingSlots(int id, Time startTime, Time endTime, String date) {
		super();
		this.id = id;
		this.startTime = startTime;
		this.endTime = endTime;
		this.date = date;
	}

	public MeetingSlots(int id, Time startTime, Time endTime, String date, MeetingRooms meetingRoom, Users bookedBy) {
		super();
		this.id = id;
		this.startTime = startTime;
		this.endTime = endTime;
		this.date = date;
		this.meetingRoom = meetingRoom;
		this.bookedBy = bookedBy;
	}

	@Override
	public String toString() {
		return "MeetingSlots [id=" + id + ", startTime=" + startTime + ", endTime=" + endTime + ", date=" + date
				+ ", meetingRoom=" + meetingRoom + ", bookedBy=" + bookedBy + "]";
	}
	
	

//	@Override
//	public String toString() {
//		return "MeetingSlots [id=" + id + ", startTime=" + startTime + ", endTime=" + endTime + ", date=" + date
//				+ ", meetingRoom=" + meetingRoom + ", bookedBy=" + bookedBy + "]";
//	}

//	@Override
//	public String toString() {
//		return "MeetingSlots [id=" + id + ", startTime=" + startTime + ", endTime=" + endTime + ", date=" + date + "]";
//	}


	
}
