package com.rakuten.letsmeet.letsmeetbackend.service;

import java.sql.Time;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rakuten.letsmeet.letsmeetbackend.dao.MeetingSlotsDao;
import com.rakuten.letsmeet.letsmeetbackend.model.MeetingRooms;
import com.rakuten.letsmeet.letsmeetbackend.model.MeetingSlots;
import com.rakuten.letsmeet.letsmeetbackend.model.Users;

@Service
public class MeetingSlotsServiceImpl implements MeetingSlotsService{
	
  private MeetingSlotsDao meetingSlotsDao;
  
  
  @Autowired
	public MeetingSlotsServiceImpl(MeetingSlotsDao theMeetingSlotsDao) {
		meetingSlotsDao = theMeetingSlotsDao;
	}

	@Override
	public List<MeetingSlots> findAll() {
		return meetingSlotsDao.findAll();
	}
	
	@Override
//	public List<MeetingSlots> findAllByDateTime(MeetingSlots meetingslots){
//	
//		return meetingSlotsDao.findAllByDateTime(meetingslots);
//	}
	
	public List<MeetingRooms> findAllByDateTime(String date,Time starttime, Time endtime){
		
		return meetingSlotsDao.findAllByDateTime(date, starttime, endtime);
	}
    public List<MeetingSlots> findByRoomId(int roomId){
		
		 return meetingSlotsDao.findByRoomId(roomId);
	}
    public Integer getUserId(String userName){
    	return meetingSlotsDao.getUserId(userName);
    }
    
    @Override
	@Transactional
	public void addSlot(Integer roomId, String startTime, String endTime , Integer userName , String date ){
		 meetingSlotsDao.addSlot(roomId,startTime,endTime,userName,date);
	}
	public List<MeetingSlots> viewbookedroom(Integer userId){
		
		return meetingSlotsDao.viewbookedroom(userId);
	}
	@Override
	@Transactional
	public void deleteById(Integer theId) {
		meetingSlotsDao.deleteById(theId);
	}
}
