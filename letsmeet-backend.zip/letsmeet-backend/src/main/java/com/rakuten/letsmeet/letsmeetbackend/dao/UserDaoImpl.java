//package com.rakuten.letsmeet.letsmeetbackend.dao;
//
//import java.util.List;
//
//import javax.persistence.EntityManager;
//
//import org.hibernate.Session;
//import org.springframework.stereotype.Repository;
//import com.rakuten.letsmeet.letsmeetbackend.model.Users;
//@Repository
//public class UserDaoImpl {
//	private EntityManager entityManager;
//	Users users=new Users();
//	public UserDaoImpl (EntityManager theEntityManager) {
//		entityManager = theEntityManager;
//	}
//	
//	public Integer findUserId(String userName) {
//		
//		Session currentSession = entityManager.unwrap(Session.class);
//		
//		String hql = "select u.userId from Users as u where userName='"+userName+ "'";
//		List thequery = currentSession.createQuery(hql).list();
//		System.out.println(thequery);
//		currentSession.save(thequery);
//		Integer id= (Integer) thequery.get(0);
//	
//		return id;
//	}
//	
//	
////	//define fields for entity manager
////		private EntityManager entityManager;
////		
////		//set up constructor injection
////		public UserDaoImpl(EntityManager theEntityManager) {
////			entityManager = theEntityManager;
////		}
////		
////
////	@Override
////	public Users findByUserName(String userName) {
////		Session currentSession = entityManager.unwrap(Session.class);	
////		
////		Users theUsers = currentSession.get(Users.class, userName);
////		return theUsers;
////	}
////
////
////	@Override
////	public Users save(Users user) {
////Session currentSession = entityManager.unwrap(Session.class);	
////		
////		 currentSession.saveOrUpdate(user);
////		return user;
////	}
//	
//}