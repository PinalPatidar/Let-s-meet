package com.rakuten.letsmeet.letsmeetbackend.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.rakuten.letsmeet.letsmeetbackend.model.MeetingRooms;

@Repository
public class MeetingRoomDaoImpl implements MeetingRoomDao {
	
	
	private EntityManager entityManager;
	
	//set up constructor injection
	public MeetingRoomDaoImpl(EntityManager theEntityManager) {
		entityManager = theEntityManager;
	}
	
	@Override
	public List<MeetingRooms> findAll() {
		
		//get the current hibernate session 
		Session currentSession = entityManager.unwrap(Session.class);
		
		//create the query
		Query<MeetingRooms> theQuery = currentSession.createQuery("from MeetingRooms",MeetingRooms.class);
		
		//execute query and get result list
		List<MeetingRooms> meetingRooms = theQuery.getResultList();
		
		//return the result
		return meetingRooms;
	}
	
	@Override
	public MeetingRooms findById(int theId) {
		Session currentSession = entityManager.unwrap(Session.class);
		
		//get the meetingroom
		MeetingRooms theMeetingRoom = currentSession.get(MeetingRooms.class, theId);
		
		//return the meeting room
		return theMeetingRoom;
	}


	@Override
	public MeetingRooms add(MeetingRooms theMeetingRoom) {
		Session currentSession = entityManager.unwrap(Session.class);
		
		//save MeetingRoom
		currentSession.saveOrUpdate(theMeetingRoom);
		return theMeetingRoom;
	}

	@Override
	public void deleteById(int theId) {
		Session currentSession = entityManager.unwrap(Session.class);
		
		//delete Meeting Room
		Query theQuery = currentSession.createQuery("delete from MeetingRooms where id=:roomId");
		theQuery.setParameter("roomId", theId);
		theQuery.executeUpdate();
	}

}
