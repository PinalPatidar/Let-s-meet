package com.rakuten.letsmeet.letsmeetbackend.service;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;


import com.rakuten.letsmeet.letsmeetbackend.model.Users;

public interface UserService {
	
	public Users findByUserName(String userName);
	
	public Users save(Users user);

	public Users active(Users user);

	public List<Users> findAll();

//	public Integer findUserId(String username);

}
