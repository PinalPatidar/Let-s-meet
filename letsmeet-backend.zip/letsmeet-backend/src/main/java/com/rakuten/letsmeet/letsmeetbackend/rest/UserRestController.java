package com.rakuten.letsmeet.letsmeetbackend.rest;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.rakuten.letsmeet.letsmeetbackend.jwt.JWTAuthenticationRequest;
import com.rakuten.letsmeet.letsmeetbackend.jwt.JWTAuthenticationResponse;
import com.rakuten.letsmeet.letsmeetbackend.jwt.JWTUtils;
import com.rakuten.letsmeet.letsmeetbackend.model.Users;
import com.rakuten.letsmeet.letsmeetbackend.service.MyUserDetailsService;
import com.rakuten.letsmeet.letsmeetbackend.service.UserService;
//import com.rakuten.letsmeet.letsmeetbackend.repo.UserRepo;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/user")
public class UserRestController {
	
	private UserService userService;

	@Autowired
	public UserRestController(UserService theUserService) {
		userService=theUserService;
	}
	
	@Autowired
	private JWTUtils jwtUtils;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private MyUserDetailsService myUserDetailsService;
	
	//private UserRepo repo;
	@PostMapping("/user")
	public ResponseEntity<Users> registerUser(@RequestBody Users user) {
		return ResponseEntity.ok(userService.save(user));
	}
	
	@PostMapping("/active")
	public ResponseEntity<Users> activeUser(@RequestBody Users user) {
		return ResponseEntity.ok(userService.active(user));
	}
	
	@GetMapping("/disable")
	public ResponseEntity<List<Users>> diableUsers() {
		return ResponseEntity.ok(userService.findAll().stream().filter(u -> !u.getIsEnabled()).collect(Collectors.toList()) );
	}
	
	
	//@GetMapping("/books/{id}")
	//public Users get(@PathVariable("id") int id) {}
		
	@PostMapping("/login")
	public ResponseEntity<?> loginUser(@RequestBody Users userData){
		System.out.println(userData);
		Users user=userService.findByUserName(userData.getUserName());
		if(user.getPassword().equals(userData.getPassword()))
			return ResponseEntity.ok(user);
		
		return (ResponseEntity<?>) ResponseEntity.internalServerError() ;
	}
	
	@PostMapping(path ="/authenticate")
	public ResponseEntity<?> authenticate(@RequestBody JWTAuthenticationRequest jWTAuthenticationRequest) throws Exception{
		try{
		
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(jWTAuthenticationRequest.getUsername(), jWTAuthenticationRequest.getPassword()));
			UserDetails userDetails = myUserDetailsService.loadUserByUsername(jWTAuthenticationRequest.getUsername());

			String token = jwtUtils.generateToken(userDetails);
			
			return ResponseEntity.ok(new JWTAuthenticationResponse(token, userDetails.getAuthorities().stream().map(GrantedAuthority::getAuthority).collect(Collectors.toList()) ));
		}catch(BadCredentialsException e) {
			throw new Exception("Invalid Credentials",e);
		}catch(AuthenticationException ex) {
			throw new Exception("Invalid Credentials auth",ex);
		}
		
	}
//	@GetMapping("/getUserByUsername/{username}")
//    public Integer findUserId(@PathVariable("username") String username){
//		Integer userId = userService.findUserId(username);
//		return userId;
//	}
	

}

