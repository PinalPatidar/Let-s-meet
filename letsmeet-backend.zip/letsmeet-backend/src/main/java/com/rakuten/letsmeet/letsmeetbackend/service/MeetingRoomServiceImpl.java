package com.rakuten.letsmeet.letsmeetbackend.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rakuten.letsmeet.letsmeetbackend.dao.MeetingRoomDao;
import com.rakuten.letsmeet.letsmeetbackend.model.MeetingRooms;

@Service
public class MeetingRoomServiceImpl implements MeetingRoomService {

	private MeetingRoomDao meetingRoomDao;
	
	@Autowired
	public MeetingRoomServiceImpl(MeetingRoomDao theMeetingRoomDao) {
		meetingRoomDao = theMeetingRoomDao;
	}
	
	@Override
	public List<MeetingRooms> findAll() {
		return meetingRoomDao.findAll();
	}

	@Override
	public MeetingRooms findById(int theId) {
		return meetingRoomDao.findById(theId);

	}
	
	@Override
	@Transactional
	public MeetingRooms add(MeetingRooms theMeetingRoom) {
		return meetingRoomDao.add(theMeetingRoom);
	}

	@Override
	@Transactional
	public void deleteById(int theId) {
		meetingRoomDao.deleteById(theId);
	}

	

}
