package com.rakuten.letsmeet.letsmeetbackend.rest;

import java.sql.Time;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rakuten.letsmeet.letsmeetbackend.model.MeetingRooms;
import com.rakuten.letsmeet.letsmeetbackend.model.MeetingSlots;
import com.rakuten.letsmeet.letsmeetbackend.model.Users;
import com.rakuten.letsmeet.letsmeetbackend.service.MeetingSlotsService;

@RestController
@RequestMapping("/api")
@CrossOrigin("http://localhost:4200")
public class MeetingSlotsRestController {
	

	private MeetingSlotsService meetingSlotsService ;
	
	@Autowired
	public MeetingSlotsRestController(MeetingSlotsService theMeetingSlotsService) {
		meetingSlotsService = theMeetingSlotsService;
	}
	@GetMapping("/meetingslots")
	public List<MeetingSlots> findAll() {
		return meetingSlotsService.findAll();
	}
	
	
//	public List<MeetingSlots> findAllByDateTime(@RequestBody MeetingSlots meetingSlots){
//		
//		MeetingSlots meetingslots = (MeetingSlots) meetingSlotsService.findAllByDateTime(meetingSlots);
//		
//		return (List<MeetingSlots>) meetingslots;
//		
//	}
//	
	@GetMapping("/searchmeetroom/{date}/{startTime}/{endTime}")
	public List<MeetingRooms> findAllByDateTime(@RequestBody @PathVariable String date ,@PathVariable Time startTime, @PathVariable Time endTime) {
		
//		List<MeetingSlots> theMeetingSlots = (List<MeetingSlots>) meetingSlotsService.findAllByDateTime( date,startTime, endTime);
		List<MeetingRooms> theMeetingSlots = (List<MeetingRooms>) meetingSlotsService.findAllByDateTime( date,startTime, endTime);

		
//		return meetingSlotsService.findAllByDateTime(date,startTime, endTime);
		return theMeetingSlots;
	}
	
	@GetMapping("meetingslots/{roomId}")
	 public List<MeetingSlots> findByRoomId(@PathVariable int roomId){
		
		System.out.println(roomId);
		List<MeetingSlots> theMeetingSlots = (List<MeetingSlots>) meetingSlotsService.findByRoomId(roomId);
		return theMeetingSlots;
	 }
	
	@PostMapping("/addslot/{roomId}/{startTime}/{endTime}/{userName}/{date}")
	public void addSlot( @PathVariable(name="roomId") Integer roomId, @PathVariable(name="startTime") String startTime,@PathVariable(name="endTime") String endTime ,@PathVariable(name="userName") Integer userName ,@PathVariable(name="date") String date ) {
	
		System.out.print(roomId);
		System.out.print(startTime);
		System.out.print(endTime);
		System.out.print(userName);
		System.out.print(date);
		
		meetingSlotsService.addSlot(roomId,startTime,endTime,userName,date);
	}
	
	@GetMapping("/userid/{userName}")
	public Integer getUserId(@PathVariable String userName){
		return  meetingSlotsService.getUserId(userName);
		
		
	}
	@GetMapping("/viewbookedroom/{userId}")
	public List<MeetingSlots> viewbookedroom(@PathVariable Integer userId){
		
		System.out.println(userId);
		
		return meetingSlotsService.viewbookedroom(userId);
	}
	
	@DeleteMapping("/deleteslot/{slotId}")
	public String delete(@PathVariable Integer slotId) {
		
		System.out.println(slotId);
		//throw exception if null
		
		meetingSlotsService.deleteById(slotId);
		return "Deleted Meeting slot id - " + slotId;
		
	}
}
