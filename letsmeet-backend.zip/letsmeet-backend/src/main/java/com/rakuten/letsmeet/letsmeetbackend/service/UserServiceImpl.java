package com.rakuten.letsmeet.letsmeetbackend.service;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rakuten.letsmeet.letsmeetbackend.dao.UserDao;

import com.rakuten.letsmeet.letsmeetbackend.jwt.MyUserDetails;
import com.rakuten.letsmeet.letsmeetbackend.model.Users;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDao userDao;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	public UserServiceImpl(UserDao theUserDao) {
		userDao= theUserDao;
	}

	

	@Override
	@Transactional
	public Users findByUserName(String userName) {
		return userDao.findByUserName(userName);
	}

	@Override
	public Users save(Users user) {
		user.setIsEnabled(false);
		return userDao.save(user);
	}

	@Override
	@Transactional
	public Users active(Users user) {
		Session currentSession = entityManager.unwrap(Session.class);
		
		
		Users userDB = findByUserName(user.getUserName());
		userDB.setIsEnabled(true);
		currentSession.merge(userDB);

		return userDB;
	}

	@Override
	public List<Users> findAll() {
		// TODO Auto-generated method stub
		return userDao.findAll();
	}

//	@Override
//	public Integer findUserId(String username) {
//		// TODO Auto-generated method stub
//		return userDaoImpl.findUserId(username);
//	}


	
	

}
