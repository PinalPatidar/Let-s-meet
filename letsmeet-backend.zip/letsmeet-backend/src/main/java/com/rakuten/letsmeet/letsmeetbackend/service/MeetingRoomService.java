package com.rakuten.letsmeet.letsmeetbackend.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.rakuten.letsmeet.letsmeetbackend.model.MeetingRooms;


public interface MeetingRoomService {
	
	public List<MeetingRooms> findAll();
	
	public MeetingRooms findById(int theId);
	
	public MeetingRooms add(MeetingRooms theMeetingRoom);
	
	public void deleteById(int theId);

	
}
