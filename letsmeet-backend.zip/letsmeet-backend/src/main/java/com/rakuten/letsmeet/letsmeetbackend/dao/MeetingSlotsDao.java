package com.rakuten.letsmeet.letsmeetbackend.dao;

import java.util.Date;
import java.sql.Time;
import java.util.List;

import com.rakuten.letsmeet.letsmeetbackend.model.MeetingRooms;
import com.rakuten.letsmeet.letsmeetbackend.model.MeetingSlots;
import com.rakuten.letsmeet.letsmeetbackend.model.Users;


public interface MeetingSlotsDao   {

	public List<MeetingSlots> findAll();
	
	public List<MeetingRooms> findAllByDateTime(String date,Time starttime, Time endtime);
	
//	public List<MeetingSlots> findAllByDateTime(MeetingSlots meetingslots);

//	public MeetingSlots meetingSlots(MeetingSlots meetingslots);
	public List<MeetingSlots> findByRoomId(int roomId);
	
	public void addSlot(Integer roomId, String startTime, String endTime , Integer userName , String date );
	
	public  Integer getUserId(String userName);

	public List<MeetingSlots> viewbookedroom(Integer userId);
	
	public void deleteById(Integer theId);
}
