package com.rakuten.letsmeet.letsmeetbackend.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;


@Entity
@Table(name="meeting_room")
public class MeetingRooms {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	@Column(name="room_id")
	private int roomId;
	
	@Column(name="room_no")
	private int roomNo;
	
	@Column(name="floor_no")
	private int floorNo;
	
	@Column(name="room_capacity")
	private int roomCapacity;
	
	@OneToMany( cascade = CascadeType.ALL)
//	@JoinColumn(name = "Meeting_Room")
	private Set<MeetingSlots> meetingslots = new HashSet<MeetingSlots>(0);
	
	public MeetingRooms() {
		
	}
	

	public MeetingRooms(int roomNo, int floorNo, int roomCapacity) {
		super();
		this.roomNo = roomNo;
		this.floorNo = floorNo;
		this.roomCapacity = roomCapacity;
	}

	

//	public MeetingRooms(int roomId, int roomNo, int floorNo, int roomCapacity, List<MeetingSlots> meetingslots) {
//		super();
//		this.roomId = roomId;
//		this.roomNo = roomNo;
//		this.floorNo = floorNo;
//		this.roomCapacity = roomCapacity;
////		this.meetingslots = meetingslots;
//	}


	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public int getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}

	public int getFloorNo() {
		return floorNo;
	}

	public void setFloorNo(int floorNo) {
		this.floorNo = floorNo;
	}

	public int getRoomCapacity() {
		return roomCapacity;
	}

	public void setRoomCapacity(int roomCapacity) {
		this.roomCapacity = roomCapacity;
	}
	
	

//	public List<MeetingSlots> getMeetingslots() {
//		return (List<MeetingSlots>) meetingslots;
//	}


	public void setMeetingslots(Set<MeetingSlots> meetingslots) {
		this.meetingslots = meetingslots;
	}


	@Override
	public String toString() {
		return "MeetingRooms [roomId=" + roomId + ", roomNo=" + roomNo + ", floorNo=" + floorNo + ", roomCapacity="
				+ roomCapacity + ", meetingslots=" + meetingslots + "]";
	}


//	@Override
//	public String toString() {
//		return "MeetingRooms [roomId=" + roomId + ", roomNo=" + roomNo + ", floorNo=" + floorNo + ", roomCapacity="
//				+ roomCapacity + "]";
//	}

	
//
//	@Override
//	public int hashCode() {
//		return Objects.hash(floorNo, meetingslots, roomCapacity, roomId, roomNo);
//	}


//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		MeetingRooms other = (MeetingRooms) obj;
//		return floorNo == other.floorNo && Objects.equals(meetingslots, other.meetingslots)
//				&& roomCapacity == other.roomCapacity && roomId == other.roomId && roomNo == other.roomNo;
//	}


	
	
	
	@Override
	public int hashCode() {
		return Objects.hash(roomId);
	}

	

//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		MeetingRooms other = (MeetingRooms) obj;
//		return roomId == other.roomId;
//	}
	
	
}
