package com.rakuten.letsmeet.letsmeetbackend.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rakuten.letsmeet.letsmeetbackend.model.MeetingRooms;

public interface MeetingRoomDao {
	
	public List<MeetingRooms> findAll();
	
	public MeetingRooms findById(int theId);
	
	public MeetingRooms add(MeetingRooms theMeetingRoom);
	
	public void deleteById(int theId);
}
