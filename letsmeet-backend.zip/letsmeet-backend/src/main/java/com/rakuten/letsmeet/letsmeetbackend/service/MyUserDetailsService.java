package com.rakuten.letsmeet.letsmeetbackend.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Optional;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.rakuten.letsmeet.letsmeetbackend.dao.UserDao;
import com.rakuten.letsmeet.letsmeetbackend.jwt.MyUserDetails;
import com.rakuten.letsmeet.letsmeetbackend.model.Users;

@Service("MyUserDetailsService")
public class MyUserDetailsService implements UserDetailsService{
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private UserDao userDao;
	
	
	@Transactional
	public UserDetails loadUserByUsername(String username) {
		Users user = userDao.findByUserName(username);
//		user.orElseThrow(()->new UsernameNotFoundException("User not found : "+username));
		UserDetails userDetails = new MyUserDetails(user);
		return userDetails;
	}
	
}