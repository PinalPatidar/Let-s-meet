package com.rakuten.letsmeet.letsmeetbackend.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.rakuten.letsmeet.letsmeetbackend.model.Users;

@Repository
public interface UserDao extends JpaRepository<Users,String> {

	public Users findByUserName(String userName);	
	
	public Users save(Users user);
	
//	public Integer findUserId(String userName);
}


