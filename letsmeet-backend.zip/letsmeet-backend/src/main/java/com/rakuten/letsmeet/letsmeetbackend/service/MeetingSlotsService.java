package com.rakuten.letsmeet.letsmeetbackend.service;

import java.sql.Time;
import java.util.Date;
import java.util.List;

import com.rakuten.letsmeet.letsmeetbackend.model.MeetingRooms;
import com.rakuten.letsmeet.letsmeetbackend.model.MeetingSlots;
import com.rakuten.letsmeet.letsmeetbackend.model.Users;

public interface MeetingSlotsService {
	
	
	
	public List<MeetingSlots> findAll();
	
//	public List<MeetingSlots> findAllByDateTime(String date,Time startTime, Time endTime);

	public List<MeetingRooms> findAllByDateTime(String date,Time startTime, Time endTime);

//	public List<MeetingSlots> findAllByDateTime(MeetingSlots meetingslots);

	public List<MeetingSlots> findByRoomId(int roomId);
	
	public void addSlot(Integer roomId, String startTime, String endTime , Integer userName , String date );
	
	public Integer getUserId(String userName);
	public List<MeetingSlots> viewbookedroom(Integer userId);
	public void deleteById(Integer theId);
}
