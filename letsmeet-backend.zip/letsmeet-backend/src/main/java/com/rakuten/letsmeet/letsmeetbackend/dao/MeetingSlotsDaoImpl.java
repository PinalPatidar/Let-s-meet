package com.rakuten.letsmeet.letsmeetbackend.dao;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.function.Function;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.FluentQuery.FetchableFluentQuery;
import org.springframework.stereotype.Repository;

import com.rakuten.letsmeet.letsmeetbackend.model.MeetingRooms;
import com.rakuten.letsmeet.letsmeetbackend.model.MeetingSlots;
import com.rakuten.letsmeet.letsmeetbackend.model.Users;

@Repository
public class MeetingSlotsDaoImpl implements MeetingSlotsDao {

	private EntityManager entityManager;
	MeetingRooms meetingroom=new MeetingRooms();
	Users users=new Users();
	
	SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);
	//set up constructor injection
		public MeetingSlotsDaoImpl(EntityManager theEntityManager) {
			entityManager = theEntityManager;
		}
	@Override
	public List<MeetingSlots> findAll() {
		
		//get the current hibernate session 
		Session currentSession = entityManager.unwrap(Session.class);
		
		//create the query
		Query<MeetingSlots> theQuery = currentSession.createQuery("from MeetingSlots",MeetingSlots.class);
		
		//execute query and get result list
		List<MeetingSlots> meetingSlots = theQuery.getResultList();
		
		//return the result
		return meetingSlots;
	}
	
	@Override
	public List<MeetingRooms> findAllByDateTime(String date,Time startTime, Time endTime)
	
//	public List<MeetingSlots> findAllByDateTime(MeetingSlots meetingslots){
	{
		Session currentSession = entityManager.unwrap(Session.class);
		

		System.out.println(date);
		System.out.println(startTime);
		System.out.println(endTime);
		
		

		Query<MeetingRooms> theQuery = currentSession.createQuery("from MeetingRooms as mr where mr.roomId not in ( select meetingRoom from MeetingSlots as m where m.startTime != '"+startTime+"' and m.endTime > '" +endTime+"' or m.date !='"+date+"')");

//		Query<MeetingRooms>theQuery2=currentSession.createQuery("\r\n"
//				+ "select distinct  mr.roomId, mr.roomNo , mr.floorNo ,mr.roomCapacity  from MeetingRooms mr left join  MeetingSlots ms on  ms.bookedBy = mr.roomId  and ms.startTime !='"+startTime+"' and  ms.date !='"+date+"'");
//		
		List<MeetingRooms> meetingRooms = theQuery.getResultList();
		
		return meetingRooms;
	}
	
	public List<MeetingSlots> findByRoomId(int roomId)
	{
		Session currentSession = entityManager.unwrap(Session.class);
		
		System.out.println(roomId);
		
		Query<MeetingSlots> theQuery = currentSession.createQuery("from MeetingSlots where meetingRoom= '" +roomId+"' ");
		
		List<MeetingSlots> meetingslots = theQuery.getResultList();
		
		System.out.println(meetingslots);

		return meetingslots;
	}
	@Override
	public void addSlot(Integer roomId, String startTime, String endTime , Integer userName , String date ){
		Session currentSession = entityManager.unwrap(Session.class);
//		Query thequery=currentSession.createQuery("select u.userId from Users as u where userName='"+userName+ "'",Users.class);
		//save MeetingRoom
//		String hql = "select u.userId from Users as u where userName='"+userName+ "'";
//		List thequery = currentSession.createQuery(hql).list();
//		
//		currentSession.save(thequery);
//		int id1=(int) thequery.get(0);
//		Integer id=id1;
//		System.out.println(id);
		
		entityManager.createNativeQuery(
		          "Insert into meeting_slots set user_id=:userName,room_id=:roomId,end_time=:endTime,start_time=:startTime,date=:date")
		          .setParameter("userName", userName).setParameter("roomId", roomId).setParameter("endTime", endTime)
		          .setParameter("startTime", startTime).setParameter("date", date).executeUpdate();

//		Query<MeetingSlots> meetsQuery=currentSession.createQuery("insert into MeetingSlots (bookedBy,startTime,endTime,date,meetingRoom) values ('"+userName+"','"+startTime+"','"+endTime+"','"+date+"','"+roomId+"'");
//		Query query= entityManager.createNativeQuery("insert into letsmeet_promo (startTime,endTime,date,meetingRoom,bookedBy) values").se
//		currentSession.save(meetsQuery);
//		meetsQuery.executeUpdate();
	}

	public Integer getUserId(String userName) {
		Session currentSession = entityManager.unwrap(Session.class);
		
		
		Integer userId = currentSession.createQuery("select u.userId from Users as u where userName='"+userName+ "'",Integer.class).getSingleResult();
		
		System.out.println(userId);
		return userId;
	}
	public List<MeetingSlots> viewbookedroom(Integer userId){
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query<MeetingSlots> theQuery = currentSession.createQuery("from MeetingSlots where bookedBy='"+userId+"'");
		List<MeetingSlots> meetingslots = theQuery.getResultList();
		System.out.println(meetingslots);
		return meetingslots;
	}
	@Override
	public void deleteById(Integer theId) {
		Session currentSession = entityManager.unwrap(Session.class);
		
		//delete Meeting Room
		Query theQuery = currentSession.createQuery("delete from MeetingSlots where id=:theId");
		theQuery.setParameter("theId", theId);
		theQuery.executeUpdate();
	}
}
