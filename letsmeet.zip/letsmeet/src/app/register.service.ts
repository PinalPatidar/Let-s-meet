import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Registration } from './registration';
import { BasicAuthenticationService } from './service/basic-authentication.service';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {
 
  baseUrl="http://localhost:8080/user/user";
  constructor(private httpClient : HttpClient,
    private basicAuthenticationService : BasicAuthenticationService) { }


  registerUser(registration :Registration):Observable<object>{

    console.log(registration);
    return this.httpClient.post(`${this.baseUrl}`,registration,this.basicAuthenticationService.getHeaders());
    
  }

  disableUser():Observable<Registration[]>{

    return this.httpClient.get<Registration[]>('http://localhost:8080/user/disable',this.basicAuthenticationService.getHeaders());
    
  }
  activateUser(user : Registration):Observable<object>{
    return this.httpClient.post('http://localhost:8080/user/active',user, this.basicAuthenticationService.getHeaders());
    
  }
}
