import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BasicAuthenticationService } from '../service/basic-authentication.service';
import { User } from '../user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username = ''
  password = ''
  errorMessage = 'Invalid Credentials'
  invalidLogin = false
  loginType = ''

  user:User=new User();
  userId!:number;
  //Router
  //Angular.giveMeRouter
  //Dependency Injection
  constructor(private router: Router,
    private basicAuthenticationService: BasicAuthenticationService) { }

  ngOnInit(): void {
  }
  
  registration(){
    this.router.navigate(['register'])
  }

  type(type : string){
    this.loginType= type;
  }

  login() { 
    this.basicAuthenticationService.executeJWTAuthenticationService(this.username, this.password)
        .subscribe(
          data => {
            console.log(data)
            this.user=data;
            console.log(this.user.userId);
            console.log(this.user);
            this.router.navigate([this.loginType, this.username])
            this.invalidLogin = false   
               
          },
          error => {
            console.log(error)
            alert("something wrong")
            this.invalidLogin = true
          }
        )
  }
  hellouser(userId:number){
    console.log(userId);
    this.router.navigate(['hellouser'])

  }
}
