import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RoomlistuserComponent } from './roomlistuser.component';

describe('RoomlistuserComponent', () => {
  let component: RoomlistuserComponent;
  let fixture: ComponentFixture<RoomlistuserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RoomlistuserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RoomlistuserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
