import { Time } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MeetingRoomDataService } from '../service/data/meeting-room-data.service';

export class MeetingRoom {
  constructor(
    public roomId: any,
    public roomNo: number,
    public floorNo: number,
    public roomCapacity: number
  ) { }
  
}


@Component({
  selector: 'app-roomlistuser',
  templateUrl: './roomlistuser.component.html',
  styleUrls: ['./roomlistuser.component.css']
})
export class RoomlistuserComponent implements OnInit {

  userId!:number;
  roomId!:any;
  meetingrooms!: MeetingRoom[]; 
  message : string= ''
  name! :''
  constructor( private meetingRoomService: MeetingRoomDataService,
    private router:Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.refreshList();
   
    this.name = this.route.snapshot.params['name'];
    console.log(this.name);
  }
  Back(){
    this.router.navigate(['hellouser',{name:this.name}])
  }
  refreshList() {
    this.meetingRoomService.retriveAllMeetingRooms().subscribe(
      response =>{
        console.log(response);
        this.meetingrooms=response;
      })
  }
  CheckRoomavailabilityy(roomId: any){
    console.log(`check roomId ${roomId}`)
     
        this.router.navigate(['list-meetingslots',{roomId:roomId,name:this.name}])
        
      }
  }



