import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Searchmeetroom } from '../searchmeetroom';
import { SearchmeetroomService } from '../searchmeetroom.service';
import { MeetingRoomDataService } from '../service/data/meeting-room-data.service';
import { User } from '../user';

export class MeetingRooms {
  constructor(
    public roomId: any,
    public roomNo: number,
    public floorNo: number,
    public roomCapacity: number
  ) { }
  
}
@Component({
  selector: 'app-availableroom',
  templateUrl: './availableroom.component.html',
  styleUrls: ['./availableroom.component.css']
})
export class AvailableroomComponent implements OnInit {
  searchmeetroom:Searchmeetroom=new Searchmeetroom();
  user:User=new User();
  roomId!:''
  roomIdd!:25
  date! :''
  data!:''
  startTime!:''
  endTime!:''
  meetingrooms!: MeetingRooms[]; 
  userName!:''
  userId!:any
  constructor(private router:Router, private route: ActivatedRoute,private searchmeetroomService : SearchmeetroomService,private meetingRoomService: MeetingRoomDataService  ) { }

  ngOnInit(): void {
    
  console.log(this.roomIdd);

    this.date = this.route.snapshot.params[`date`];
 
    this.userName=this.route.snapshot.params['userName'];
    this.startTime=this.route.snapshot.params['startTime'];
    this.endTime=this.route.snapshot.params['endTime'];
    console.log(this.date);
    console.log(this.startTime);
    console.log(this.endTime);
    // this.meetingrooms=this.data;

    this.refreshList(this.date,this.startTime,this.endTime);
  }
  CheckRoomavailabilityy(roomId:any){

  }
  refreshList(date:any,startTime:any,endTime:any){
    this.searchmeetroomService.meetroom(this.searchmeetroom.date,this.startTime,this.endTime).subscribe(
      data =>{
      console.log(data);
      this.meetingrooms=data;
     
    },error=>alert("Sorry,something is wrong"));
  }
  bookroom(roomId:any){

    this.meetingRoomService.getUserId(this.userName).subscribe(response=>{


      
      this.userId=response;
      console.log(this.userId);
      this.meetingRoomService.bookroom(roomId,this.startTime,this.endTime,this.userId,this.date).subscribe(
        response=> {
      
      console.log(this.date);
      console.log(this.startTime);
      console.log(this.endTime);
      console.log(this.userName);
      console.log(this.userId);
      this.refreshList(this.date,this.startTime,this.endTime);
     
    })
    alert("meeting room is booked")
    this.refreshList(this.date,this.startTime,this.endTime);
    
    })
 
}
  Back(){
    this.router.navigate(['searchmeetingroom'])
  }
}
