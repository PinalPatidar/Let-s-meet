import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterService } from '../register.service';
import { Registration } from '../registration';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  registration:Registration= new Registration();
  constructor(private registerservice : RegisterService , private router :Router ) { }

  
  ngOnInit(): void {
  }
  register(){
    
  }
  userRegister(){
   console.log(this.registration);
   this.registerservice.registerUser(this.registration).subscribe((data)=>{
   
    alert("Successfully User is register");
    this.router.navigate([`/login`])

   },(error)=>alert("Sorry user is not Registered"));
   

  }
}
