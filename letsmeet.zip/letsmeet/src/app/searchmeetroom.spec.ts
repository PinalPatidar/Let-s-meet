import { Searchmeetroom } from './searchmeetroom';

describe('Searchmeetroom', () => {
  it('should create an instance', () => {
    expect(new Searchmeetroom()).toBeTruthy();
  });
});
