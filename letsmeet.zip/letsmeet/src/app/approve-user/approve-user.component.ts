import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterService } from '../register.service';
import { Registration } from '../registration';

@Component({
  selector: 'app-approve-user',
  templateUrl: './approve-user.component.html',
  styleUrls: ['./approve-user.component.css']
})
export class ApproveUserComponent implements OnInit {

  users!:Registration[]
  constructor(private registerservice : RegisterService , private router :Router) { }

  ngOnInit(): void {
    this.getDisableUsers();
  }

  getDisableUsers(){
    this.registerservice.disableUser().subscribe(
      response =>{
        console.log(response);
        this.users=response;
      })
  }

  approveUser(username: string){
    let user = new Registration();
    user.userName = username;
    this.registerservice.activateUser(user).subscribe(
      response =>{
        console.log(response);
        this.getDisableUsers();
      })
  }

}
