import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchmeetingroomComponent } from './searchmeetingroom.component';

describe('SearchmeetingroomComponent', () => {
  let component: SearchmeetingroomComponent;
  let fixture: ComponentFixture<SearchmeetingroomComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchmeetingroomComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchmeetingroomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
