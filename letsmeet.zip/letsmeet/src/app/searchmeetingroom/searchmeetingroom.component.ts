import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Searchmeetroom } from '../searchmeetroom';
import { SearchmeetroomService } from '../searchmeetroom.service';

@Component({
  selector: 'app-searchmeetingroom',
  templateUrl: './searchmeetingroom.component.html',
  styleUrls: ['./searchmeetingroom.component.css']
})


export class SearchmeetingroomComponent implements OnInit {

  searchmeetroom:Searchmeetroom=new Searchmeetroom();
  minDate = new Date();
  maxDate=this.minDate 
userName=''
 startTime=''
 endTime=''
 date=''
  constructor(private searchmeetroomService : SearchmeetroomService , private router :Router,private route: ActivatedRoute) { }

  ngOnInit(): void {
    let date = new Date;
    this.userName = this.route.snapshot.params['name'];
    console.log(this,this.userName);
  }

  datetimepicker(slot:any,date:any){
    if(slot==1){
      this.startTime="01:00:00";
      this.endTime="02:00:00";
    }
    if(slot==2){
      this.startTime="02:00:00";
      this.endTime="03:00:00";
    }
    if(slot==3){
      this.startTime="03:00:00";
      this.endTime="04:00:00";
    }
    if(slot==4){
      this.startTime="04:00:00";
      this.endTime="05:00:00";
    }
    if(slot==5){
      this.startTime="05:00:00";
      this.endTime="06:00:00";
    }
    if(slot==6){
      this.startTime="06:00:00";
      this.endTime="07:00:00";
    }
    if(slot==7){
      this.startTime="07:00:00";
      this.endTime="08:00:00";
    }
    if(slot==8){
      this.startTime="08:00:00";
      this.endTime="09:00:00";
    }
    if(slot==9){
      this.startTime="09:00:00";
      this.endTime="10:00:00";
    }
    if(slot==10){
      this.startTime="10:00:00";
      this.endTime="11:00:00";
    }
    if(slot==11){
      this.startTime="11:00:00";
      this.endTime="12:00:00";
    }
    if(slot==12){
      this.startTime="12:00:00";
      this.endTime="13:00:00";
    }
    if(slot==13){
      this.startTime="13:00:00";
      this.endTime="14:00:00";
    }
    if(slot==14){
      this.startTime="14:00:00";
      this.endTime="15:00:00";
    }
    if(slot==15){
      this.startTime="15:00:00";
      this.endTime="16:00:00";
    }
    if(slot==16){
      this.startTime="16:00:00";
      this.endTime="17:00:00";
    }
    if(slot==17){
      this.startTime="17:00:00";
      this.endTime="18:00:00";
    }
    if(slot==18){
      this.startTime="18:00:00";
      this.endTime="19:00:00";
    }
    if(slot==19){
      this.startTime="19:00:00";
      this.endTime="20:00:00";
    }
    if(slot==20){
      this.startTime="20:00:00";
      this.endTime="21:00:00";
    }
    if(slot==21){
      this.startTime="21:00:00";
      this.endTime="22:00:00";
    }
    if(slot==22){
      this.startTime="22:00:00";
      this.endTime="23:00:00";
    }
    if(slot==23){
      this.startTime="23:00:00";
      this.endTime="24:00:00";
    }
    
   console.log(this.startTime,this.endTime,this.date);
    
    // this.searchmeetroomService.meetroom(this.searchmeetroom.date,this.startTime,this.endTime).subscribe(data=>{
      
     console.log(this,this.userName);
      // let navigationParameters = [data];
      // this.router.navigate([`availableroom`,{date:this.searchmeetroom.date},{startTime:this.startTime},{endTime:this.endTime}]);
      this.router.navigate([`availableroom`,this.searchmeetroom.date,this.startTime,this.endTime,this.userName]);
      // this.router.navigate([`availableroom`]);
      // alert("done..! check available meeting room")
     
      // this.router.navigate([`availableroom`,navigationParameters]);
     
      
    // },error=>alert("Sorry,something is wrong"));

  }
}
