import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MeetingRoomDataService } from '../service/data/meeting-room-data.service';


export class MeetingSlotss {
  constructor(
    public id: number,
    public startTime: any,
    public endTime: any,
   public date: any,
   public Meeting_Room:number,
   public Booked_By:number

  ) { }
}
@Component({
  selector: 'app-bookedroom',
  templateUrl: './bookedroom.component.html',
  styleUrls: ['./bookedroom.component.css']
})
export class BookedroomComponent implements OnInit {
  meetingSlots!:MeetingSlotss[];
  userName!:''

  userId!:any

  constructor(private router :Router,private route: ActivatedRoute,private meetingRoomService: MeetingRoomDataService) { }


  ngOnInit(): void {
    this.userName = this.route.snapshot.params['name'];
    this.refreshList(this.userName);
  }

  back(){
  this.router.navigate(['hellouser'])
  }

  refreshList(userName:any){

    this.meetingRoomService.getUserId(this.userName).subscribe(response=>{



      console.log(userName);
      this.userId=response;
      console.log(this.userId);
      this.meetingRoomService.viewbookedroom(this.userId).subscribe(

        data=>{
          console.log(data)
          this.meetingSlots=data;
          
        })
        

      })
  }
  deletslot(Id:any){
    console.log(Id);
    this.meetingRoomService.deletslot(Id).subscribe(
      data=>{
        
        alert("Succesfully Deleted");

      }
     
    )
    this.refreshList(this.userName);
  }

}
