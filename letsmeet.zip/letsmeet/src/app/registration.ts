export class Registration {
    userName!:string;
    firstName!:string;
    lastName!:string;
    email!:string;
    password!:string;
}
