import { Time } from "@angular/common";

export class Searchmeetroom {
    date!:'';
    startTime!:'';
    endTime!:'';
}
