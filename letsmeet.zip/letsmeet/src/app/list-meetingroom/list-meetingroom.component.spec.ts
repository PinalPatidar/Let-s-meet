import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListMeetingroomComponent } from './list-meetingroom.component';

describe('ListMeetingroomComponent', () => {
  let component: ListMeetingroomComponent;
  let fixture: ComponentFixture<ListMeetingroomComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListMeetingroomComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListMeetingroomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
