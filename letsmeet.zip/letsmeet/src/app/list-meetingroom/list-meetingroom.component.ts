import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MeetingRoomDataService } from '../service/data/meeting-room-data.service';

export class MeetingRoom {
  constructor(
    public roomId: any,
    public roomNo: number,
    public floorNo: number,
    public roomCapacity: number
  ) { }
}
@Component({
  selector: 'app-list-meetingroom',
  templateUrl: './list-meetingroom.component.html',
  styleUrls: ['./list-meetingroom.component.css']
})
export class ListMeetingroomComponent implements OnInit {
  
  meetingrooms!: MeetingRoom[]; 
 
  message : string= ''
 

constructor(
    private meetingRoomService: MeetingRoomDataService,
    private router: Router
  ) { }
 

  ngOnInit(): void {
    this.refreshList();
  }

  refreshList() {
    this.meetingRoomService.retriveAllMeetingRooms().subscribe(
      response =>{
        console.log(response);
        this.meetingrooms=response;
      })
  }

  deleteMeetingRoom(roomId: any){
    console.log(`delete Meeting Room ${roomId}`)
    this.meetingRoomService.deleteMeetingroom(roomId).subscribe(
      response=>{
        this.message = "if the room is aleready booked by someone you have to wait for delete else room deleted"
        this.refreshList();
        console.log(response);
        
      })
      this.refreshList();
      alert("if the room is aleready booked by someone you have to wait for delete else room deleted");
      // this.message = `Meeting Room deleted successfully`
      this.refreshList();
    }
  

  updateMeetingRoom(roomId: any) {
    console.log(`updare ${roomId}`)
    this.router.navigate(['meetingroom', roomId])
   
  }

  addMeetingRoom() {
    // this.router.navigate(['meetingroom',1])
      this.router.navigate(['meetingroom'])

  }

}
