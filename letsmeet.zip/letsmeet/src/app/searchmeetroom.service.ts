import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { MeetingRooms } from './availableroom/availableroom.component';
import { Searchmeetroom } from './searchmeetroom';
import { BasicAuthenticationService } from './service/basic-authentication.service';

@Injectable({
  providedIn: 'root'
})
export class SearchmeetroomService {

  private baseUrl="http://localhost:8080/api/searchmeetroom";
  constructor(private httpClient : HttpClient,private basicAuthenticationService : BasicAuthenticationService) { }

    meetSearch(searchmeetroom: Searchmeetroom):Observable<object>{
      console.log(searchmeetroom)

      return this.httpClient.post(`${this.baseUrl}`, searchmeetroom,this.basicAuthenticationService.getHeaders() );
}
meetroom(date:any,startTime:any,endTime:any){
  return  this.httpClient.get<MeetingRooms[]>(`${this.baseUrl}/${date}/${startTime}/${endTime}`, this.basicAuthenticationService.getHeaders());
}
}
