import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  adminId = 'Pinal'
  password = ''
  errorMessage = 'Invalid Credentials'
  invalidLogin = false;

  //router
  //Angular.giveMeRouter
  //Dependency injection

  constructor(private router : Router) { }

  ngOnInit(): void {
  }
  handleLogin() {
    console.log(this.adminId)
    //console.log(this.password)

   if(this.adminId==="Pinal" && this.password==='123') 
   {
     this.router.navigate(['helloadmin', this.adminId]) 
     this.invalidLogin = false
     
   } else {
    this.invalidLogin = true
   }
 }
}
