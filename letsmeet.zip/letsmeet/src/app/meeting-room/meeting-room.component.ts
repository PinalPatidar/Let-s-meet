import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MeetingRoom } from '../list-meetingroom/list-meetingroom.component';
import { MeetingRoomDataService } from '../service/data/meeting-room-data.service';

@Component({
  selector: 'app-meeting-room',
  templateUrl: './meeting-room.component.html',
  styleUrls: ['./meeting-room.component.css']
})
export class MeetingRoomComponent implements OnInit {

  roomId! : number;
  meetingRoom! : MeetingRoom;

  constructor(
    private MeetingRoomService: MeetingRoomDataService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.roomId = this.route.snapshot.params['roomId'];
    // dummy ojject required
    this.meetingRoom =new MeetingRoom(null,0,0,0);
    if(this.roomId>0) {
      this.MeetingRoomService.retriveMeetingRoom(this.roomId).subscribe (
        data => this.meetingRoom = data
      )
    }
    
   }

  addMRoom() {
    if(this.roomId=== -1) {
      this.MeetingRoomService.createMeetingRoom(this.meetingRoom).subscribe
      (data=> {
        console.log(data)
        this.router.navigate(['list-meetingroom'])
      })
    } else {
      this.MeetingRoomService.updateMeetingRoom(this.meetingRoom)
      .subscribe(
        data=> {
          console.log(data)
          this.router.navigate(['list-meetingroom'])
        },(error)=>alert("Enter valid Details"));
      
    }
  }
}
