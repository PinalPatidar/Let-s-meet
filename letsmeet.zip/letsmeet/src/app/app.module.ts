import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { HelloadminComponent } from './helloadmin/helloadmin.component';
import { ErrorComponent } from './error/error.component';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { HellouserComponent } from './hellouser/hellouser.component';
import { RegistrationComponent } from './registration/registration.component';
import { ListMeetingroomComponent } from './list-meetingroom/list-meetingroom.component';
import { MeetingRoomComponent } from './meeting-room/meeting-room.component';
import { HeaderComponent } from './header/header.component';
import { LogoutComponent } from './logout/logout.component';
import { ApproveUserComponent } from './approve-user/approve-user.component';
import { SearchmeetingroomComponent } from './searchmeetingroom/searchmeetingroom.component';
import { RoomlistuserComponent } from './roomlistuser/roomlistuser.component';
import { ListMeetingslotsComponent } from './list-meetingslots/list-meetingslots.component';
import { BookedroomComponent } from './bookedroom/bookedroom.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import { MatTableModule } from '@angular/material/table' ;
import {MatIconModule} from '@angular/material/icon'; 
import {MatCardModule} from '@angular/material/card';
import {MatToolbarModule} from '@angular/material/toolbar';
import { AvailableroomComponent } from './availableroom/availableroom.component';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatTabsModule} from '@angular/material/tabs';

@NgModule({
  declarations: [
    AppComponent,
    AdminloginComponent,
    HelloadminComponent,
    ErrorComponent,
    LoginComponent,
    HellouserComponent,
    RegistrationComponent,
    ListMeetingroomComponent,
    MeetingRoomComponent,
    HeaderComponent,
    LogoutComponent,
    ApproveUserComponent,
    SearchmeetingroomComponent,
    RoomlistuserComponent,
    ListMeetingslotsComponent,
    BookedroomComponent,
    AvailableroomComponent,


    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatFormFieldModule,
    MatInputModule ,
    MatButtonModule,
    MatTableModule,
    MatIconModule,
    MatCardModule,
    MatToolbarModule,
    MatCheckboxModule,
    MatTabsModule
       
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
