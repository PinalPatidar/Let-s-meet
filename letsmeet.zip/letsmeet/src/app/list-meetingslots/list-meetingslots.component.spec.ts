import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListMeetingslotsComponent } from './list-meetingslots.component';

describe('ListMeetingslotsComponent', () => {
  let component: ListMeetingslotsComponent;
  let fixture: ComponentFixture<ListMeetingslotsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListMeetingslotsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListMeetingslotsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
