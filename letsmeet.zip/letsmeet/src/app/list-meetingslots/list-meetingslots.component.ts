import { formatDate, Time } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MeetingRoomDataService } from '../service/data/meeting-room-data.service';

export class MeetingSlots {
  constructor(
    public Id: any,
    public startTime: any,
    public endTime: any,
   public date: any,
   public Meeting_Room:number,
   public Booked_By:number

  ) { }
}
export class slotTime{
  constructor(listt:[string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string]){}
}

var time = new Date();
let list: number[] = [1, 2, 3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24];
 var times= time.toLocaleString('en-US', { hour: 'numeric', hour12:false })
console.log(
 time.toLocaleString('en-US', { hour: 'numeric', hour12:false })
 
); 
@Component({
  selector: 'app-list-meetingslots',
  templateUrl: './list-meetingslots.component.html',
  styleUrls: ['./list-meetingslots.component.css']
})
export class ListMeetingslotsComponent implements OnInit {
  userName!:'';
  name!:'';
  slot!:any;
  roomId! : number;
  meetingSlots!:MeetingSlots[];
  vals=24-parseInt(times);
  // list: any[] = [1, 2, 3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23];
  
  list: any[] = ['11:00:00', '12:00:00','13:00:00','14:00:00',"15:00:00","16:00:00","17:00:00","18:00:00","19:00:00","20:00:00","21:00:00"];
  // list: any[] = ['01:00:00', '02:00:00','03:00:00','04:00:00',"05:00:00","06:00:00","07:00:00","08:00:00","09:00:00","10:00:00","04:00:00","11:00:00","12:00:00","13:00:00","14:00:00","15:00:00","16:00:00","17:00:00","18:00:00","19:00:00","20:00:00","21:00:00","22:00:00","23:00:00"];

    arr=[this.vals];
    
    // {{date  | date:'yyyy-MM-dd'}}
    // arr[0]=1;
    myDate = new Date();
    date = formatDate(this.myDate, 'yyyy-MM-dd', 'en-US');

    userId!:any;
    startTime!:any;
    endTime!:any;
    slotTime!:slotTime;
    // startTime
  constructor(private meetingRoomService: MeetingRoomDataService,
    private router: Router,  private route: ActivatedRoute) { }

  ngOnInit(): void {
    
    this.roomId = this.route.snapshot.params['roomId'];
    this.userName = this.route.snapshot.params['name'];
    // this.CheckRoomavailability(this.Id);
    this.slotTime =new slotTime(["01:00:00" , "02:00:00","03:00:00","04:00:00","05:00:00","04:00:00","04:00:00","04:00:00","04:00:00","04:00:00","04:00:00","04:00:00","04:00:00","04:00:00","04:00:00","04:00:00"]);
    console.log(this.roomId);
    console.log(this.name);
    this.CheckRoomavailability(this.roomId);
  }

  CheckRoomavailability(roomId: any){
    this.meetingRoomService.CheckRoomavailability(roomId).subscribe(
      response=> {
        console.log(response);
       this.meetingSlots=response;
       console.log(times);
      })
  }
  bookroom(slot:any){

    if(slot=="01:00:00"){
      this.startTime="01:00:00";
      this.endTime="02:00:00";
    }
    if(slot=="02:00:00"){
      this.startTime="02:00:00";
      this.endTime="03:00:00";
    }
    if(slot=="03:00:00"){
      this.startTime="03:00:00";
      this.endTime="04:00:00";
    }
    if(slot=="04:00:00"){
      this.startTime="04:00:00";
      this.endTime="05:00:00";
    }
    if(slot=="05:00:00"){
      this.startTime="05:00:00";
      this.endTime="06:00:00";
    }
    if(slot=="06:00:00"){
      this.startTime="06:00:00";
      this.endTime="07:00:00";
    }
    if(slot=="07:00:00"){
      this.startTime="07:00:00";
      this.endTime="08:00:00";
    }
    if(slot=="08:00:00"){
      this.startTime="08:00:00";
      this.endTime="09:00:00";
    }
    if(slot=="09:00:00"){
      this.startTime="09:00:00";
      this.endTime="10:00:00";
    }
    if(slot=="10:00:00"){
      this.startTime="10:00:00";
      this.endTime="11:00:00";
    }
    if(slot=="11:00:00"){
      this.startTime="11:00:00";
      this.endTime="12:00:00";
    }
    if(slot=="12:00:00"){
      this.startTime="12:00:00";
      this.endTime="13:00:00";
    }
    if(slot=="13:00:00"){
      this.startTime="13:00:00";
      this.endTime="14:00:00";
    }
    if(slot=="14:00:00"){
      this.startTime="14:00:00";
      this.endTime="15:00:00";
    }
    if(slot=="15:00:00"){
      this.startTime="15:00:00";
      this.endTime="16:00:00";
    }
    if(slot=="16:00:00"){
      this.startTime="16:00:00";
      this.endTime="17:00:00";
    }
    if(slot=="17:00:00"){
      this.startTime="17:00:00";
      this.endTime="18:00:00";
    }
    if(slot=="18:00:00"){
      this.startTime="18:00:00";
      this.endTime="19:00:00";
    }
    if(slot=="19:00:00"){
      this.startTime="19:00:00";
      this.endTime="20:00:00";
    }
    if(slot=="20:00:00"){
      this.startTime="20:00:00";
      this.endTime="21:00:00";
    }
    if(slot=="21:00:00"){
      this.startTime="21:00:00";
      this.endTime="22:00:00";
    }
    if(slot=="22:00:00"){
      this.startTime="22:00:00";
      this.endTime="23:00:00";
    }
    if(slot=="23:00:00"){
      this.startTime="23:00:00";
      this.endTime="24:00:00";
    }
  

    // this.startTime=this.slot;
    // var minutesToAdd=30;
    // this.endTime=this.startTime + (minutesToAdd*60000);
  //   this.meetingRoomService.bookroom(this.roomId,this.startTime,this.endTime,this.userName,this.date).subscribe(
  //     response=> {
  //   console.log(slot);
  //   console.log(this.date);
  //   console.log(this.startTime);
  //   console.log(this.endTime);
  //   console.log(this.name);
  // })
  this.meetingRoomService.getUserId(this.userName).subscribe(response=>{


      
    this.userId=response;
    console.log(this.userId);
    this.meetingRoomService.bookroom(this.roomId,this.startTime,this.endTime,this.userId,this.date).subscribe(
      response=> {
    
    console.log(this.date);
    console.log(this.startTime);
    console.log(this.endTime);
    console.log(this.userName);
    console.log(this.userId);
    this.CheckRoomavailability(this.roomId);
  })
  this.CheckRoomavailability(this.roomId);
  })
  }
  Back(){
    
  }
}
