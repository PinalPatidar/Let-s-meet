import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HelloadminComponent } from './helloadmin.component';

describe('HelloadminComponent', () => {
  let component: HelloadminComponent;
  let fixture: ComponentFixture<HelloadminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HelloadminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HelloadminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
