import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BasicAuthenticationService } from '../service/basic-authentication.service';

@Component({
  selector: 'app-helloadmin',
  templateUrl: './helloadmin.component.html',
  styleUrls: ['./helloadmin.component.css']
})

export class HelloadminComponent implements OnInit {

  name!:''
  //ActivatedRoute

  constructor(private route: ActivatedRoute,
    private router: Router, private basicAuthenticationService : BasicAuthenticationService) { }

  ngOnInit(): void {
  this.name=this.route.snapshot.params['name'];
  console.log(this.route.snapshot.params['name']);
  }

  listOfMeetingRoom(){
  this.router.navigate(['list-meetingroom'])
  }
  approveUser(){
    this.router.navigate(['approve-user'])
  }

  logout(){
    this.basicAuthenticationService.logout();
    this.router.navigate(['login'])
  }
}