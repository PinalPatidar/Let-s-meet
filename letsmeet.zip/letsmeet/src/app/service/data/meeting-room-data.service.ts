import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MeetingSlotss } from 'src/app/bookedroom/bookedroom.component';
import { MeetingRoom } from 'src/app/list-meetingroom/list-meetingroom.component';
import { MeetingSlots } from 'src/app/list-meetingslots/list-meetingslots.component';
import { User } from 'src/app/user';
import { BasicAuthenticationService } from '../basic-authentication.service';

@Injectable({
  providedIn: 'root'
})
export class MeetingRoomDataService {

  constructor(
    private http: HttpClient,
    private basicAuthenticationService : BasicAuthenticationService
  ) { }

  retriveAllMeetingRooms() {
    return this.http.get<MeetingRoom[]>('http://localhost:8080/api/meetingroom',this.basicAuthenticationService.getHeaders());
    // console.log("all meeting rooms");
  }

  deleteMeetingroom(roomId: any){
    return this.http.delete(`http://localhost:8080/api/meetingroom/${roomId}`, this.basicAuthenticationService.getHeaders());
  }

  retriveMeetingRoom(roomId: any) {
    return this.http.get<MeetingRoom>(`http://localhost:8080/api/meetingroom/${roomId}`, this.basicAuthenticationService.getHeaders());
  }

  updateMeetingRoom(meetingRoom:MeetingRoom) {
    return this.http.put(`http://localhost:8080/api/updatemeetingroom`,meetingRoom, this.basicAuthenticationService.getHeaders());
  }

  createMeetingRoom(meetingRoom:MeetingRoom) {
    return this.http.post(`http://localhost:8080/api/add`,meetingRoom, this.basicAuthenticationService.getHeaders());
  }

  CheckRoomavailability(roomId: any) {
    return this.http.get<MeetingSlots[]>(`http://localhost:8080/api/meetingslots/${roomId}`, this.basicAuthenticationService.getHeaders());
  }

  bookroom(roomId:any,startTime:any,endTime:any,userName:any,date:any){
    return  this.http.post(`http://localhost:8080/api/addslot/${roomId}/${startTime}/${endTime}/${userName}/${date}`,{}, this.basicAuthenticationService.getHeaders());
  }
  getUserId(userName:any){

    return this.http.get<User>(`http://localhost:8080/api/userid/${userName}`, this.basicAuthenticationService.getHeaders());
  }
  viewbookedroom(userId:any){

    return this.http.get<MeetingSlotss[]>(`http://localhost:8080/api/viewbookedroom/${userId}`,this.basicAuthenticationService.getHeaders());
  }
  deletslot(id:any){
    return this.http.delete(`http://localhost:8080/api/deleteslot/${id}`,this.basicAuthenticationService.getHeaders());
  }
}


