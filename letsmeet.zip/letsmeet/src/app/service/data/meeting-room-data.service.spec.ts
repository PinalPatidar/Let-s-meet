import { TestBed } from '@angular/core/testing';

import { MeetingRoomDataService } from './meeting-room-data.service';

describe('MeetingRoomDataService', () => {
  let service: MeetingRoomDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MeetingRoomDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
