import { BasicAuthenticationService } from './../basic-authentication.service';
import { HttpInterceptor, HttpHandler, HttpRequest, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HttpIntercepterBasicAuthService implements HttpInterceptor{

  constructor(
    private basicAuthenticationService : BasicAuthenticationService
  ) { }

  intercept(request: HttpRequest<any>, next: HttpHandler){
    // let username = 'in28minutes'
    // let password = 'dummy'
    //let basicAuthHeaderString = 'Basic ' + window.btoa(username + ':' + password);
    let basicAuthHeaderString = this.basicAuthenticationService.getAuthenticatedToken();
    let username = this.basicAuthenticationService.getAuthenticatedUser()

    // if(basicAuthHeaderString && username) { 
    //   request = request.clone({
    //     headers: new HttpHeaders({
    //       'Authorization': basicAuthHeaderString + '',
    //       'Host': 'localhost:8080',
    //       'Origin': 'http://localhost:4200'
    //     }),
    //     responseType: 'text' as 'json'
    //   }) 
    // }
    return next.handle(request);
  }


}
