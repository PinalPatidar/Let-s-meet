import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { ErrorComponent } from './error/error.component';
import { HelloadminComponent } from './helloadmin/helloadmin.component';
import { HellouserComponent } from './hellouser/hellouser.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
// import { UserloginComponent } from './userlogin/userlogin.component';
import { ListMeetingroomComponent } from './list-meetingroom/list-meetingroom.component';
import { MeetingRoomComponent } from './meeting-room/meeting-room.component';
import { RouteGuardService } from './service/route-guard.service';
import { LogoutComponent } from './logout/logout.component';
import { UserRouteGuardService } from './service/user-route-guard.service';
import { ApproveUserComponent } from './approve-user/approve-user.component';
import { SearchmeetingroomComponent } from './searchmeetingroom/searchmeetingroom.component';
import { RoomlistuserComponent } from './roomlistuser/roomlistuser.component';
import { ListMeetingslotsComponent } from './list-meetingslots/list-meetingslots.component';
import { BookedroomComponent } from './bookedroom/bookedroom.component';
import { AvailableroomComponent } from './availableroom/availableroom.component';
const routes: Routes = [
  {path:'',component: LoginComponent},
  {path:'login',component: LoginComponent},
  {path:'adminlogin',component: AdminloginComponent, canActivate:[RouteGuardService]},
  // {path:'userlogin',component: UserloginComponent, canActivate:[UserRouteGuardService]},
  {path:'hellouser',component: HellouserComponent, canActivate:[UserRouteGuardService]},
  {path:'hellouser/:name',component: HellouserComponent, canActivate:[UserRouteGuardService]},
  {path:'hellouser/:name/:Id',component: HellouserComponent, canActivate:[UserRouteGuardService]},
  {path:'register',component: RegistrationComponent},
  {path:'meetingroom/:roomId',component: MeetingRoomComponent, canActivate:[RouteGuardService]},
  {path:'meetingroom',component: MeetingRoomComponent, canActivate:[RouteGuardService]},
  {path:'list-meetingroom',component: ListMeetingroomComponent, canActivate:[RouteGuardService]},
  {path:'helloadmin/:name',component: HelloadminComponent, canActivate:[RouteGuardService]},
  {path:'logout',component: LogoutComponent},
  {path:'approve-user',component: ApproveUserComponent, canActivate:[RouteGuardService]},
  {path:'searchmeetingroom',component:SearchmeetingroomComponent ,canActivate:[UserRouteGuardService]},
  {path:'searchmeetingroom/:name',component:SearchmeetingroomComponent ,canActivate:[UserRouteGuardService]},
  {path: 'roomlistuser',component:RoomlistuserComponent,canActivate:[UserRouteGuardService] },
  {path: 'list-meetingslots' ,component:ListMeetingslotsComponent,canActivate:[UserRouteGuardService]},
  {path: 'bookedroom',component:BookedroomComponent,canActivate:[UserRouteGuardService] },
  {path: 'bookedroom/:name',component:BookedroomComponent,canActivate:[UserRouteGuardService] },
  {path:'availableroom/:date/:startTime/:endTime/:userName',component:AvailableroomComponent,canActivate:[UserRouteGuardService]},
  {path:'**',component: ErrorComponent},
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
