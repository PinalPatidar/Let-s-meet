import { TestBed } from '@angular/core/testing';

import { SearchmeetroomService } from './searchmeetroom.service';

describe('SearchmeetroomService', () => {
  let service: SearchmeetroomService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SearchmeetroomService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
