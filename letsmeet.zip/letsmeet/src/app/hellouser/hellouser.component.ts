import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, ActivatedRouteSnapshot, Router } from '@angular/router';
import { BasicAuthenticationService } from '../service/basic-authentication.service';
import { User } from '../user';

@Component({
  selector: 'app-hellouser',
  templateUrl: './hellouser.component.html',
  styleUrls: ['./hellouser.component.css']
})
export class HellouserComponent implements OnInit {
user:User=new User();
  name! :''
  Id!:''

 
  constructor(private router:Router, private route: ActivatedRoute,private basicAuthenticationService : BasicAuthenticationService) { }

  
  ngOnInit(): void {

   this.name = this.route.snapshot.params['name'];
 
   console.log('name:',this.name);
   
  }
  userDuty(){
    this.router.navigate(['searchmeetingroom',{name:this.name}])
  }
  CheckMeetRoom(){
    this.router.navigate(['roomlistuser',{name:this.name}])
    // this.router.navigate(['roomlistuser'])
  }
  bookedRoom(){
    this.router.navigate(['bookedroom',{name:this.name}])

  }
  logout(){
    this.basicAuthenticationService.logout();
    this.router.navigate(['login'])
  }
}
